/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercicio2;

/**
 *
 * @author matheus.barbosa
 */
public class Exercicio2 {

    private final int[] notas;
    private int contador = 0;

    Exercicio2(int[] notas) {
        this.notas = notas;
    }

    public int comparator() {
        for (int i = 1; i < notas.length; i++) {
            if (notas[i] > notas[i - 1]) {
                contador = contador + 2;
                i++;
            }
        }
        return notas.length - contador;
    }
}
