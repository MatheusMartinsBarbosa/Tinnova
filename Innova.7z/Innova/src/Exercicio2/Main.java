/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercicio2;

import java.util.Scanner;

/**
 *
 * @author matheus.barbosa
 */
public class Main {
    
    public static void main(String args[]) throws Exception {
        Scanner sc = new Scanner(System.in);
        int numeroAlunos = 0;
        System.out.println("Digite o numero de alunos na fila: ");
        
        try {
            numeroAlunos = sc.nextInt();
        } catch (Exception e) {
            throw new Exception("Entrada inválida");
        }

        int[] notas = new int [numeroAlunos];
        for (int i = 0; i < numeroAlunos; i++) {
            System.out.println(String.format("Digite a nota do aluno n° %s", i));
            notas[i] = sc.nextInt();
        }

        Exercicio2 exercicio = new Exercicio2(notas);
        System.out.println("Saida: " + exercicio.comparator());

    }

}
