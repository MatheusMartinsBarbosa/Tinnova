/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercicio1;

import java.util.Scanner;

/**
 *
 * @author matheus.barbosa
 */
public class Main {

    public static void main(String args[]) throws Exception {
        Scanner sc = new Scanner(System.in);
        int temp = 0;
        System.out.println("Digita uma temperatura em Farenheit:");
        
        try {
            temp = sc.nextInt();
        } catch (Exception e) {
            throw new Exception("Entrada inválida");
        }
        
        Exercicio1 conv = new Exercicio1(temp);
        System.out.println("Temperatura em °Celcius: " + conv.converter());
    }

}
