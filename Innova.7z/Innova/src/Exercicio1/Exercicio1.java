/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercicio1;

import java.util.Scanner;

/**
 *
 * @author matheus.barbosa
 */
public class Exercicio1 {

    private final int temperatura;

    Exercicio1(int temperatura) {
        this.temperatura = temperatura;
    }

    public int converter() throws Exception {

        if (this.temperatura < 1 || this.temperatura > 300) {
            throw new Exception("Temperatura inválida");
        }

        int result = (5 * (this.temperatura - 32) / 9);
        return result;
    }

}
