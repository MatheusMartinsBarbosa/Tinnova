package innova.demo.infra.repository;

import innova.demo.model.EntidadeVeiculo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;

@Repository
public interface IVeiculoRepository extends JpaRepository<EntidadeVeiculo, Long> {

    @Query(value = "select * " +
            "from veiculo v", nativeQuery = true)
    List<EntidadeVeiculo> listarVeiculos();

    @Query(value = "select * " +
            "from veiculo v " +
            "where v.id = :id", nativeQuery = true)
    List<EntidadeVeiculo> listarVeiculoID(@Param("id") long id);

    @Query(value = "select count(*) " +
            "from veiculo v " +
            "where v.vendido = false", nativeQuery = true)
    String listarVeiculoNaoVendidos();

    @Query(value = "select count(*)" +
            "from veiculo v " +
            "groupy by marca", nativeQuery = true)
    List<String> listarVeiculoPorFabricante();



}
