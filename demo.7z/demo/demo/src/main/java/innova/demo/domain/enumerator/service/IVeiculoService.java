package innova.demo.domain.enumerator.service;

import innova.demo.aplication.dto.in.InParametrosVeiculos;
import innova.demo.model.EntidadeVeiculo;

import java.util.List;

public interface IVeiculoService {

    List<EntidadeVeiculo>listarVeiculos();

    List<EntidadeVeiculo>listarVeiculoID(long id);

    String addVeiculo(InParametrosVeiculos params);

    String deleteVeiculo(long id);

    String atualizaVeiculo(long id, InParametrosVeiculos veiculoAtualizado);

    String atualizaVeiculoPATCH(long id, InParametrosVeiculos veiculoAtualizado);

    String listarVeiculoNaoVendidos();

    List<String> listarVeiculoPorFabricante();
}
