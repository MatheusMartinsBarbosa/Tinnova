package innova.demo.aplication;

import innova.demo.aplication.dto.in.InParametrosVeiculos;
import innova.demo.infra.service.VeiculoService;
import innova.demo.model.EntidadeVeiculo;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/TesteTinnova")
public class Controller {

    @Autowired
    private VeiculoService veiculoService;

    // <editor-fold defaultstate="collapsed" desc="get Todos veiculos">
    @ApiOperation(value = "Veiculos")
    @GetMapping(value = "/veiculos")
    public List<EntidadeVeiculo> getTodosVeiculos() {
        return (List<innova.demo.model.EntidadeVeiculo>) this.veiculoService.listarVeiculos();
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="get veiculo por ID">
    @ApiOperation(value = "Veiculos")
    @GetMapping(value = "/veiculoID/{id}")
    public List<EntidadeVeiculo> getVeiculoID(@PathVariable(value="id") long id) {
        return (List<innova.demo.model.EntidadeVeiculo>) this.veiculoService.listarVeiculoID(id);
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="add Veiculo">
    @ApiOperation(value = "Veiculos")
    @PostMapping(value = "/veiculo", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public String addVeiculo(@RequestBody InParametrosVeiculos params) {
        return (String) this.veiculoService.addVeiculo(params);
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="delete Veiculo">
    @ApiOperation(value = "Veiculos")
    @DeleteMapping(value = "/veiculo/{id}")
    public String deleteVeiculo(@PathVariable(value="id") long id) {
        return (String) this.veiculoService.deleteVeiculo(id);
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="atualiza Veiculo">
    @ApiOperation(value = "Veiculos")
    @PutMapping(value = "/veiculo/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public String atualizaVeiculo(@PathVariable(value="id") long id, @RequestBody InParametrosVeiculos params) {
        return (String) this.veiculoService.atualizaVeiculo(id, params);
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="atualiza partes Veiculo">
    @ApiOperation(value = "Veiculos")
    @PatchMapping(value = "/veiculo/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public String atualizaParteVeiculo(@PathVariable(value="id") long id, @RequestBody InParametrosVeiculos params) {
        return (String) this.veiculoService.atualizaVeiculoPATCH(id, params);
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Veiculos nao vendidos">
    @ApiOperation(value = "Veiculos")
    @GetMapping(value = "/veiculoNaoVendidos/")
    public String getVeiculosNaovendidos() {
        return (String) this.veiculoService.listarVeiculoNaoVendidos();
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Veiculos nao vendidos">
    @ApiOperation(value = "Veiculos")
    @GetMapping(value = "/numeroVeiculoPorFabricante/")
    public List<String> listarVeiculoPorFabricante() {
        return (List<String>) this.veiculoService.listarVeiculoPorFabricante();
    }
    // </editor-fold>
}
