package innova.demo.aplication.dto.in;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InParametrosVeiculos {

    private ParametrosVeiculos parametrosVeiculos;

}
