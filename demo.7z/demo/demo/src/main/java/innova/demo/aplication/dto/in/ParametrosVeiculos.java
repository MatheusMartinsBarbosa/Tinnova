package innova.demo.aplication.dto.in;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import innova.demo.domain.enumerator.Marca;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class ParametrosVeiculos {

    @JsonProperty(value = "veiculo")
    private String veiculo;

    @JsonProperty(value = "marca")
    private Marca marca;

    @JsonProperty(value = "ano")
    private int ano;

    @JsonProperty(value = "descricao")
    private String descricao;

    @JsonProperty(value = "vendido")
    private boolean vendido;

    @JsonIgnore
    private LocalDateTime created;
    @JsonIgnore
    private LocalDateTime updated;


}
