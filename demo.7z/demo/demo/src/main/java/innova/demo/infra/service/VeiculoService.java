package innova.demo.infra.service;

import innova.demo.aplication.dto.in.InParametrosVeiculos;
import innova.demo.domain.enumerator.service.IVeiculoService;
import innova.demo.infra.repository.IVeiculoRepository;
import innova.demo.model.EntidadeVeiculo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class VeiculoService implements IVeiculoService {

    @Autowired
    private IVeiculoRepository repository;

    @Override
    public List<EntidadeVeiculo> listarVeiculos() {
        return this.repository.listarVeiculos();
    }

    @Override
    public List<EntidadeVeiculo> listarVeiculoID(long id) {
        return this.repository.listarVeiculoID(id);
    }

    @Override
    public String addVeiculo(InParametrosVeiculos params) {
        EntidadeVeiculo veiculo = new EntidadeVeiculo();
        veiculo.setAno(params.getParametrosVeiculos().getAno());
        veiculo.setVeiculo(params.getParametrosVeiculos().getVeiculo());
        veiculo.setDescricao(params.getParametrosVeiculos().getDescricao());
        veiculo.setMarca(params.getParametrosVeiculos().getMarca());
        veiculo.setVendido(params.getParametrosVeiculos().isVendido());
        veiculo.setCreated(LocalDateTime.now());
        veiculo.setUpdated(LocalDateTime.now());
        this.repository.save(veiculo);
        return "OK";
    }

    @Override
    public String deleteVeiculo(long id) {
        try {
            this.repository.deleteById(id);
        } catch (Exception ex) {
            return "Indice invalido";
        }

        return "OK";
    }

    @Override
    public String atualizaVeiculo(long id, InParametrosVeiculos veiculoAtualizado) {
        Optional<EntidadeVeiculo> veiculo = this.repository.findById(id);
        if (veiculo.isPresent()) {
            veiculo.get().setMarca(veiculoAtualizado.getParametrosVeiculos().getMarca());
            veiculo.get().setVendido(veiculoAtualizado.getParametrosVeiculos().isVendido());
            veiculo.get().setDescricao(veiculoAtualizado.getParametrosVeiculos().getDescricao());
            veiculo.get().setVeiculo(veiculoAtualizado.getParametrosVeiculos().getVeiculo());
            veiculo.get().setAno(veiculoAtualizado.getParametrosVeiculos().getAno());
            veiculo.get().setUpdated(LocalDateTime.now());

            this.repository.save(veiculo.get());
            return "OK, registro atualizado";
        }

        return "Registro nao encontrado";

    }

    @Override
    public String atualizaVeiculoPATCH(long id, InParametrosVeiculos veiculoAtualizado) {
        Optional<EntidadeVeiculo> veiculo = this.repository.findById(id);
        if (veiculo.isPresent()) {
            veiculo.get().setMarca(veiculoAtualizado.getParametrosVeiculos().getMarca());
            veiculo.get().setVendido(veiculoAtualizado.getParametrosVeiculos().isVendido());
            veiculo.get().setDescricao(veiculoAtualizado.getParametrosVeiculos().getDescricao());
            veiculo.get().setVeiculo(veiculoAtualizado.getParametrosVeiculos().getVeiculo());
            veiculo.get().setAno(veiculoAtualizado.getParametrosVeiculos().getAno());
            veiculo.get().setUpdated(LocalDateTime.now());

            this.repository.save(veiculo.get());
            return "OK, registro atualizado";
        }
        return "Registro nao encontrado";
    }

    @Override
    public String listarVeiculoNaoVendidos() {
        String valor = this.repository.listarVeiculoNaoVendidos();
        return String.format("Numero de veiculos nao vendidos: %s", valor);
    }

    @Override
    public List<String> listarVeiculoPorFabricante() {
        return this.repository.listarVeiculoPorFabricante();
    }

}
