package innova.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

public class InnovaDemo {

    @SpringBootApplication
    public static class InnovaDemoApplication {

        public static void main(String[] args) {
            SpringApplication.run(InnovaDemoApplication.class, args);
        }

    }


}
